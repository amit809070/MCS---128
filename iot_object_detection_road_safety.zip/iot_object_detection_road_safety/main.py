import cv2
from ultralytics import YOLO
import serial
import time

# Arduino setup
try:
    arduino = serial.Serial('COM3', 9600, timeout=1)
    time.sleep(2)
except:
    arduino = None
    print("Arduino not connected")

# Load YOLO model
model = YOLO('yolov8n.pt')

cap = cv2.VideoCapture(0)

while True:
    success, frame = cap.read()

    if not success:
        break

    results = model(frame)

    danger = False

    for r in results:
        boxes = r.boxes

        for box in boxes:
            cls = int(box.cls[0])
            conf = float(box.conf[0])

            x1, y1, x2, y2 = map(int, box.xyxy[0])

            label = model.names[cls]

            if conf > 0.5:
                cv2.rectangle(frame, (x1,y1), (x2,y2), (0,255,0), 2)
                cv2.putText(frame, label, (x1,y1-10),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0,255,0), 2)

                if label in ['car', 'truck', 'bus', 'person', 'motorbike']:
                    danger = True

    if arduino:
        if danger:
            arduino.write(b'1')
        else:
            arduino.write(b'0')

    if danger:
        cv2.putText(frame, 'WARNING: OBJECT DETECTED',
                    (20,50),
                    cv2.FONT_HERSHEY_SIMPLEX,
                    1,
                    (0,0,255),
                    3)

    cv2.imshow('Road Safety Detection', frame)

    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()
