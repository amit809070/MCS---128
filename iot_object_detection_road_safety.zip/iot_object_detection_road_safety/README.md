# IoT Object Detection for Road Accident Prevention

## Technologies Used
- Python
- OpenCV
- YOLOv8
- Arduino UNO
- IoT Sensors

## Features
- Real-time object detection
- Vehicle and obstacle detection
- Accident warning buzzer
- Arduino integration
- Machine learning model support

## Installation
Install Python packages:

pip install opencv-python ultralytics pyserial numpy

## Run Project
python main.py

## Hardware Required
- Arduino UNO
- USB Camera
- Buzzer
- HC-SR04 Sensor

## Arduino Pins
- Buzzer -> Pin 8
